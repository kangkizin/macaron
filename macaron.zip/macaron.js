//macaron.js

$(document).ready(function(){
	$('.section').mousewheel(function(event, delta){
				if (delta>0)
				{
					//alert("UP");
					var prev_pos=$(this).prev().position().top;
					$("html, body").stop().animate({"scrollTop":prev_pos},1200,"easeInSine");
				}else if (delta<0)
				{
					//alert("DOWN")
					var next_pos=$(".mid").next().position().top;
					$("html, body").stop().animate({"scrollTop":next_pos},1200,"easeInSine");
				}//if
				event.preventDefault();
			});//section mousewheel

		$(".navi").click(function(){
			var goto=$(".mid").next().position().top;
			$("html, body").stop().animate({"scrollTop":goto},1300,"easeOutSine");
		});
			
			
			$(".containerimbox").click(function(){
				img1=$(this).find("img").attr("src");
				text1=$(this).find(".imboxtext").text();
				console.log(img1, text1);
				
				
				$(".black1").stop().fadeIn(1000);
				
				$(".boximg").attr("src",img1);
				$(".boxtext").text(text1);
			});

			$(".black1").click(function(){
				$(".black1").stop().fadeOut(400);
			});
});//doc