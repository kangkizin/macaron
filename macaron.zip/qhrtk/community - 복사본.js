//community.js


$(document).ready(function(){
		$(".cofa>.rright, .coqn>.rright, .coloc>.rright").hide();



/*-----------Ŭ���� ����Ű---------------------*/
		$(".cono").click(function(){
		
			$(".article div .wow").removeClass("fadeInDown");
			$(".cono>.rright").show();
			$(".cofa>.rright, .coqn>.rright, .coloc>.rright").hide();
			$(".art1>div .wow").addClass("fadeInDown");
			
		});

		$(".cofa").click(function(){
			
			$(".article div .wow").removeClass("fadeInDown");
			$(".cofa>.rright").show();
			$(".cono>.rright, .coqn>.rright, .coloc>.rright").hide();
			$(".art2>div .wow").addClass("fadeInDown");
		});
		$(".coqn").click(function(){
			
			$(".article div .wow").removeClass("fadeInDown");
			$(".coqn>.rright").show();
			$(".cono>.rright, .cofa>.rright, .coloc>.rright").hide();
			$(".art3>div .wow").addClass("fadeInDown");
		});
		$(".coloc").click(function(){
			
			$(".article div .wow").removeClass("fadeInDown");
			$(".coloc>.rright").show();
			$(".cono>.rright, .cofa>.rright, .coqn>.rright").hide();
			$(".art4>div .wow").addClass("fadeInDown");
		});
		

/*---------------����ũž �޴� �ڽ� --------------------*/
		$(".section .comback .menubox").click(function(){
				$(".section .comback .menubox").fadeOut(800,function(){
			$(".section .comback .cognbb").stop().slideDown();
			});
		});
		$(".section .comback .cognbb .cotitle").click(function(){
				$(".section .comback .cognbb").slideUp(function(){
					$(".section .comback .menubox").fadeIn(800);
				});
		
		});
/*-----------���콺���ͽ� �޽� ȿ��------------*/
		$(".cono").mouseenter(function(){
			$(this).addClass("pulse").css({"animation-iteration-count":"infinite"});
		}).mouseleave(function(){
			$(this).removeClass("pulse");
		});

		$(".cofa").mouseenter(function(){
			$(this).addClass("pulse").css({"animation-iteration-count":"infinite"});
		}).mouseleave(function(){
			$(this).removeClass("pulse");
		});

		$(".coqn").mouseenter(function(){
			$(this).addClass("pulse").css({"animation-iteration-count":"infinite"});
		}).mouseleave(function(){
			$(this).removeClass("pulse");
		});

		$(".coloc").mouseenter(function(){
			$(this).addClass("pulse").css({"animation-iteration-count":"infinite"});
		}).mouseleave(function(){
			$(this).removeClass("pulse");
		});


/*--------------�̵�� ������ ���� ����-------------------------*/

			var mql = window.matchMedia("screen and (max-width: 576px)");

		if (mql.matches) {
			$(".section .comback .cocenter .labelbox label span").remove("span");
		} 
	
/*-------------------------notice Ŭ���� ���� ���̺���-------------------------------------*/

	/*$(".cono,.btn").click(function(){
		$("section").css({"height":"175vh"});
	});

	$(".cofa").click(function(){
		$("section").css({"height":"100vh"});
	});

	$(".coqn").click(function(){
		$("section").css({"height":"100vh"});
	});

	$(".coloc").click(function(){
		$("section").css({"height":"100vh"});
	});*/
});//doc