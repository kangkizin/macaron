// main.js

$(document).ready(function(){
		$(".header, .section, .footer").css("display","none");
/*		page=1;//0일때 01234, 1일때 12345
		cnt=$(".section>img").length;//2개
		console.log(cnt);

	page=1;
		function fade(){
			page++;
			console.log(page);
			
			if (page==cnt+1)
			{
				page=1;//마지막까지 왔을때 처음으로 돌아갈 페이지 번호
			}//if
				$('.section>img').stop().fadeOut(4000);
				$(".img"+page).stop().fadeIn(4000);

		};//fade();
		fadestop=setInterval(function(){fade()},5000);*/

		$(".allblack").delay(3500).fadeOut(function(){
			$(".header, .section, .footer").fadeIn();
		});
});//doc