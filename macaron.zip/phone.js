//phone.js

$(document).ready(function(){

	$(".phone .phonemenu").click(function(){
	$(".phone>.black, .phone>.phonebox").css({"display":"block"});
	});
	
	$(".close").click(function(){
		$(".phonebox").fadeOut();
	});

});//doc