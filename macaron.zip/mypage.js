//mypage.js

$(document).ready(function(){
	
			// Get the modal
			var modal = document.getElementById('id01');

			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				if (event.target == modal) {
					modal.style.display = "none";
				}
			}

			// Get the modal
			var modal2 = document.getElementById('id02');

			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				if (event.target == modal2) {
					modal2.style.display = "none";
				}
			}
			// Get the modal
			var modal3 = document.getElementById('id03');

			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				if (event.target == modal2) {
					modal3.style.display = "none";
				}
			}

//			var mql = window.matchMedia("screen and (max-width: 576px)");

//		if (mql.matches) {
//			$(".section .mypage .pink .pac").removeClass("wow");
//		} 


			//var max =576;
			//var wid = $(window).width();
			//console.log(wid);
});//doc