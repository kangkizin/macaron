//templete.js

$(document).ready(function(){
	
	$(".menu").mouseenter(function(){
		$(".header>.gnb>li>.menu_b").stop().slideDown()
	});
	$(".menu_b").mouseleave(function(){
			$(".header>.gnb>li>.menu_b").stop().slideUp()
		});
	
	$(".menu").click(function(){
		$(".header>.gnb>li>.menu_b").stop().slideDown()
	});
	
	$(".phone .phonemenu").click(function(){
		$(".phone>.black, .phone>.phonebox").fadeIn();
	});
	
	$(".closee, .black").click(function(){
		$(".phonebox, .black").fadeOut();
	});
});//doc