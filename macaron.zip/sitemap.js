//sitemap.js


$(document).ready(function(){
	$(".smm").click(function(){
		$(".sitemapct li .wow").addClass("fadeInDown").css({"animation-delay":"0.5s"});
		$(".section>.mypage>.right .rightcard").css({"display":"none"});
		$(".header").css({"display":"none"});
	});

	$(".closebtn").click(function(){
		$(".sitemapct li .wow").removeClass("fadeInDown");
		$(".section>.mypage>.right .rightcard").delay(500).css({"display":"block"});
		$(".header").delay(500).css({"display":"block"});
	});
});