//etc.js


$(document).ready(function(){
	$(".breadbox>a>.text1").click(function(){
		$(".breadbox>.breadboxin").animate({left:"0px"},800);
	});
	$(".breadbox>.breadboxin>.lasttext",this).click(function(){
		$(".breadbox>.breadboxin").stop().animate({left:"-1200px"});
	});

	$(".lattebox>a>.text2").click(function(){
		$(".lattebox>.latteboxin").animate({right:"0px"},800);
	});
	$(".lattebox>.latteboxin>.lasttext",this).click(function(){
		$(".lattebox>.latteboxin").stop().animate({right:"-1200px"});
	});
	
});//doc